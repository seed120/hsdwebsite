<?php

	/*
		Hook: hirxpert_footer_top.
	*
	* @hooked hirxpert_insta_footer - 10
		*/
	do_action( 'hirxpert_footer_top' );
