<?php 
 // silence is golden