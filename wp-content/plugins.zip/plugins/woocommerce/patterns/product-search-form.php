<?php
/**
 * Title: Product Search
 * Slug: woocommerce/product-search-form
 * Inserter: no
 * Categories: WooCommerce
 */
?>

<!-- wp:search {"showLabel":false,"placeholder":"<?php echo esc_attr_x( 'Search products…', 'placeholder for search field', 'woocommerce' ); ?>","buttonText":"<?php echo esc_attr_x( 'Search', 'button label of product search block', 'woocommerce' ); ?>","query":{"post_type":"product"}} /-->
