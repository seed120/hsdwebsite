<?php

/**

 * The template for coming soon footer

 *

 */

?>

		</div><!-- .hirxpert-content-wrapper -->

	</div><!-- #page -->

<?php wp_footer(); ?>

</body>

</html>